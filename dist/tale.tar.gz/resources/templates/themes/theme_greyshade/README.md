# Tale主题 greyshade



## 使用方法

1. 下载最新版 Tale 程序
2. 将该项目下载下来之后存放在 `/templates/themes` 文件夹下
3. 在后台 -> 系统设置 -> 选择该主题，保存即可
4. 目前还需要重启一下 `Tale`

## 预览

![theme1.png](https://ooo.0o0.ooo/2017/03/01/58b5acaa2aebe.png)

![theme2.png](https://ooo.0o0.ooo/2017/03/01/58b5acaa0de0d.png)

![theme3.png](https://ooo.0o0.ooo/2017/03/01/58b5aca824ad3.png)

![theme4.png](https://ooo.0o0.ooo/2017/03/01/58b5ac9dc0b0a.png)

![theme5.png](https://ooo.0o0.ooo/2017/03/01/58b5aca79faea.png)

